// Pixiv user's public novels. Pixiv's profile/novels endpoint is not a paginated
// list in the same shape as search; obtain IDs from profile/all, then resolve
// novel metadata with profile/novels?ids[]=... .
function execute(url, page) {
    const userId = String(url || "").trim();
    if (!/^\d+$/.test(userId)) return Response.success([]);

    const offset = Math.max(0, parseInt(page || "0", 10) || 0);
    const limit = 30;
    const profileResponse = fetch("https://www.pixiv.net/ajax/user/" + userId + "/profile/all?lang=en");
    if (!profileResponse || !profileResponse.ok) return null;
    const profileDoc = profileResponse.json();
    if (!profileDoc || !profileDoc.body) return Response.success([]);

    const body = profileDoc.body;
    let raw = body.novels || body.novel || body.novelIds || [];
    let ids = [];
    if (Array.isArray(raw)) {
        ids = raw.map(item => String(item && typeof item === "object" ? (item.id || item.novelId || "") : item));
    } else if (raw && typeof raw === "object") {
        // Pixiv profile/all intentionally stores novel IDs with null values.
        // Keep the keys themselves; filtering null values would erase every novel.
        ids = Object.keys(raw);
    }
    ids = ids.filter(id => /^\d+$/.test(id));
    // Newest first, matching the usual Pixiv user profile order.
    ids = ids.reverse();
    const pageIds = ids.slice(offset, offset + limit);
    if (!pageIds.length) return Response.success([]);

    // Bulk metadata endpoint is more reliable than assuming profile/all contains titles.
    let meta = {};
    try {
        const query = pageIds.map(id => "ids%5B%5D=" + encodeURIComponent(id)).join("&");
        const metaResponse = fetch("https://www.pixiv.net/ajax/user/" + userId + "/profile/novels?" + query + "&lang=en");
        if (metaResponse && metaResponse.ok) {
            const metaDoc = metaResponse.json();
            const mb = metaDoc && metaDoc.body;
            if (mb && typeof mb === "object") {
                meta = mb.novels || mb.works || mb;
            }
        }
    } catch (e) {}

    const data = [];
    pageIds.forEach(id => {
        let item = meta && meta[id] ? meta[id] : null;
        let title = item && (item.title || item.name) || "";
        let cover = item && (item.url || item.coverUrl || item.thumbnail) || "";
        let description = item && (item.description || item.userName) || "";
        // Some Pixiv responses return IDs only; fetch individual details as fallback.
        if (!title) {
            try {
                const detailResponse = fetch("https://www.pixiv.net/ajax/novel/" + id + "?lang=en");
                if (detailResponse && detailResponse.ok) {
                    const detailDoc = detailResponse.json();
                    const novel = detailDoc && detailDoc.body;
                    if (novel) {
                        title = novel.title || "";
                        cover = cover || novel.coverUrl || "";
                        description = description || novel.userName || "";
                    }
                }
            } catch (e) {}
        }
        data.push({
            name: title || ("Pixiv Novel " + id),
            link: "https://www.pixiv.net/novel/show.php?id=" + id,
            cover: cover,
            description: description,
            host: "https://www.pixiv.net"
        });
    });

    const next = offset + limit < ids.length ? String(offset + limit) : null;
    return Response.success(data, next);
}
