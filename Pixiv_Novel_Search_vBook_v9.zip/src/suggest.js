// Paginated Pixiv novel-series contents. `last_order` is an offset, not a page number.
function execute(input, next) {
    const seriesId = String(input || "").trim();
    if (!/^\d+$/.test(seriesId)) return Response.success([]);

    const offset = Math.max(0, parseInt(next || "0", 10) || 0);
    const limit = 30;
    const api = "https://www.pixiv.net/ajax/novel/series_content/" + seriesId +
        "?limit=" + limit + "&last_order=" + offset + "&order_by=asc&lang=en";

    const response = fetch(api);
    if (!response || !response.ok) return null;
    const doc = response.json();
    const body = doc && doc.body;
    if (!body) return Response.success([]);

    const pageData = body.page && body.page.seriesContents;
    const novels = body.thumbnails && body.thumbnails.novel;
    let items = Array.isArray(novels) ? novels : [];
    if (!items.length && Array.isArray(pageData)) {
        items = pageData.map(item => {
            if (item && item.id) return item;
            const id = item && (item.novelId || item.id);
            return id ? { id: id, title: item.title } : null;
        }).filter(Boolean);
    }

    const data = [];
    items.forEach(item => {
        if (!item || !item.id) return;
        data.push({
            name: item.title || ("Pixiv Novel " + item.id),
            link: "https://www.pixiv.net/novel/show.php?id=" + item.id,
            cover: item.url || item.coverUrl || "",
            description: body.userName || "",
            host: "https://www.pixiv.net"
        });
    });

    // Keep the series expandable even when it has fewer than 30 novels.
    // The first non-empty response advertises a continuation token; if the
    // series is shorter than one page, the follow-up request returns no items
    // and terminates normally. Use the actual number received as the cursor.
    const nextPage = data.length > 0 ? String(offset + data.length) : null;
    return Response.success(data, nextPage);
}
