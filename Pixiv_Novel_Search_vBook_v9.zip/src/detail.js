function execute(url) {
    let book_id = String(url).split("id=")[1];
    if (book_id && book_id.includes("&")) book_id = book_id.split("&")[0];
    if (!book_id) return null;

    let response = fetch("https://www.pixiv.net/ajax/novel/" + book_id);
    if (!response.ok) return null;

    let doc = response.json();
    if (!doc || !doc.body) return null;
    let obj = doc.body;

    let genres = [];
    if (obj.tags && obj.tags.tags) {
        obj.tags.tags.forEach(e => {
            if (e && e.tag) genres.push({
                title: e.tag,
                input: encodeURIComponent(e.tag),
                script: "gen2.js"
            });
        });
    }

    let suggests = [];
    try {
        if (obj.seriesNavData && obj.seriesNavData.seriesId) {
            suggests.push({
                title: "📚 Series: " + obj.seriesNavData.title,
                input: String(obj.seriesNavData.seriesId),
                script: "suggest.js"
            });
        }
    } catch (e) {}

    // Keep author as plain text: VBook renders the author field as a label,
    // and HTML here is displayed literally on some versions. Provide a native
    // clickable suggestion row routed to author.js instead.
    const userId = obj.userId ? String(obj.userId) : "";
    const userName = String(obj.userName || "Pixiv user");
    // Expose the author listing as a clickable chip as well as a suggestion row.
    // Some VBook builds do not render custom `suggests` consistently, while
    // clickable `genres` are visible in the detail page on both legacy/new apps.
    if (userId) {
        genres.unshift({
            title: "📚 Novel của tác giả: " + userName,
            input: userId,
            script: "author.js"
        });
        suggests.push({
            title: "📚 Novel khác của tác giả: " + userName,
            input: userId,
            script: "author.js"
        });
    }

    return Response.success({
        name: obj.title,
        cover: obj.coverUrl,
        author: userName,
        description: (obj.createDate || "") + "<br/>Like: " + (obj.likeCount || 0) + "<br/>View: " + (obj.viewCount || 0) + "<br/>" + (obj.description || ""),
        comment: { input: book_id, script: "comment.js" },
        suggests: suggests,
        genres: genres,
        detail: "作者： " + userName +
            (userId ? "<br/>Pixiv user ID: " + userId : ""),
        host: "https://www.pixiv.net"
    });
}
