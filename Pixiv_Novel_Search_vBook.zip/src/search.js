function execute(key, page) {
    if (!key) return Response.error("Vui lòng nhập từ khóa");
    if (!page) page = "1";

    // Pixiv Novel search API. s_mode=s_tag searches tags/title/description.
    // Encode the keyword so Japanese/Chinese/Vietnamese and spaces work correctly.
    const word = String(key).trim();
    const encoded = encodeURIComponent(word);
    const url = "https://www.pixiv.net/ajax/search/novels/" + encoded +
        "?word=" + encoded +
        "&order=date_d&mode=all&p=" + page +
        "&s_mode=s_tag&gs=0&lang=en";

    const response = fetch(url);
    if (!response.ok) return null;

    const doc = response.json();
    if (!doc || !doc.body || !doc.body.novel || !doc.body.novel.data) return null;

    const data = [];
    doc.body.novel.data.forEach(e => {
        if (!e || !e.id) return;
        data.push({
            name: e.title || ("Pixiv Novel " + e.id),
            link: "https://www.pixiv.net/novel/show.php?id=" + e.id,
            description: e.userName || "Pixiv",
            cover: e.url,
            host: "https://www.pixiv.net"
        });
    });

    if (data.length === 0) return Response.success([]);

    const nextPage = (parseInt(page, 10) + 1).toString();
    return Response.success(data, nextPage);
}
