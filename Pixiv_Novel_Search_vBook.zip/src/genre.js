function execute() {
    return Response.success([
        {title: "原神", input: encodeURIComponent("原神"), script: "gen2.js"},
        {title: "崩坏：星穹铁道", input: encodeURIComponent("崩坏：星穹铁道"), script: "gen2.js"},
        {title: "ブルーアーカイブ", input: encodeURIComponent("ブルーアーカイブ"), script: "gen2.js"},
        {title: "Fate", input: encodeURIComponent("Fate"), script: "gen2.js"},
        {title: "恋愛", input: encodeURIComponent("恋愛"), script: "gen2.js"},
        {title: "ファンタジー", input: encodeURIComponent("ファンタジー"), script: "gen2.js"},
        {title: "異世界", input: encodeURIComponent("異世界"), script: "gen2.js"},
        {title: "中文", input: encodeURIComponent("中文"), script: "gen2.js"},
        {title: "百合", input: encodeURIComponent("百合"), script: "gen2.js"}
    ]);
}
