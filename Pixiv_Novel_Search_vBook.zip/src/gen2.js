function execute(url, page) {
    if (!page) page = '1';

    const tag = decodeURIComponent(String(url));
    const encoded = encodeURIComponent(tag);
    const api = "https://www.pixiv.net/ajax/search/novels/" + encoded +
        "?word=" + encoded +
        "&order=date_d&mode=all&p=" + page +
        "&s_mode=s_tag_full&gs=0&lang=en";

    const response = fetch(api);
    if (!response.ok) return null;

    const doc = response.json();
    if (!doc || !doc.body || !doc.body.novel || !doc.body.novel.data) return null;

    const data = [];
    doc.body.novel.data.forEach(e => {
        if (!e || !e.id) return;
        data.push({
            name: e.title,
            link: "https://www.pixiv.net/novel/show.php?id=" + e.id,
            description: e.userName,
            cover: e.url,
            host: "https://www.pixiv.net"
        });
    });

    if (data.length === 0) return Response.success([]);
    return Response.success(data, (parseInt(page, 10) + 1).toString());
}
